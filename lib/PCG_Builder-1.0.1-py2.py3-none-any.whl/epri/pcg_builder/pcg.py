#!/usr/bin/env python
# -*- coding: utf-8 -*-
#********************************************************#
# This file is part of PCG Builder.                      #
#                                                        #
# Copyright (c) 2020, Electric Power Research Institute. #
#                                                        #
# GRIDOPT is released under the BSD 3-clause license.    #
#********************************************************#
from __future__ import print_function
import os, sys

try:
    import method_error as errors
except ModuleNotFoundError:
    import epri.pcg_builder.method_error as errors

class PCG:
    """
    Protection control group (PCG) class

    :param parser: Powerflow file parser object
    :param index: PCG list index
    """

    def __init__(self, parser, index):

        self.parser = parser
        self.indx = index
        self.sub_indx = self.get_sub_indx()
        self.in_study_spec = self.get_in_study_spec()
        self.is_truncated = self.is_pcg_truncated()

    def is_pcg_truncated(self):
        """
        Retrieve truncation flag for PCG

        :returns: flag *(bool)*
        """
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}
        
        # Get data from dll
        res = self.parser.is_pcg_truncated(self.indx)
        (err, flag) = (res[0]=="True", res[1])

        if err == False:
            return flag=='True'
        else:
            err = getattr(errors, err_dict[int(flag)])
            raise err
        
    def get_branches(self):
        """
        Retrieve data for branches associated with a PCG

        :returns: [{'from_bus': bus # *(int)*, 'from_name': name *(str)*,
                    'to_bus: bus # *(int)*, 'to_name': name *(str)*,
                    'tertiary_bus': bus # *(int)*, 'tertiary_name': name *(str)*,
                    'ckt': circuit id *(str)*, 'type': branch type *(str)*,
                    'status': branch status *(bool)*,
                    'R12': R -> From - To *(float)*, 'X12': X -> From - To *(float)*,
                    'R23': R -> To - Tertiary *(float)*, 'X23': X -> To - Tertiary *(float)*,
                    'R31': R -> Tertiary - From *(float)*, 'X31': X -> Tertiary - From *(float)*},...]
        """

        if self.is_truncated == True:
            return []
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}

        # Get data from dll
        res = self.parser.get_branches(self.indx)
        (err, brns) = (res[0]=="True", res[1:])

        if err == False:

            buses = self.get_pcg_buses()
            star_buses = {key:[] for key, val in buses.items() if val['star_bus'] == True}

##            print('TEST1!!!')
            if brns == []:
                return []
            else:
                tmp = []
                for line in brns:
                    
                    fr, fr_name, to, to_name, ckt, btype, status, r, x, b = line.split(',')

                    if btype.strip().lower() == 'e3windxfm':
                        for key in star_buses.keys():
                            if key == int(fr):
                                star_buses[key].append([int(to), to_name.strip(), ckt.strip(),
                                                        btype.strip(), status.strip(),
                                                        float(r), float(x), float(b)])
                            elif key == int(to):
                                star_buses[key].append([int(fr), fr_name.strip(), ckt.strip(),
                                                        btype.strip(), status.strip(),
                                                        float(r), float(x), float(b)])

                    else:
                        tert = None
                        tert_name = 'None'

                        dct = {fr:fr_name, to:to_name}
                        sorted_buses = sorted([fr, to])
                        
                        tmp.append({'from_bus':int(sorted_buses[0]), 'from_name':dct[sorted_buses[0]].strip(),\
                                    'to_bus':int(sorted_buses[1]), 'to_name':dct[sorted_buses[1]].strip(),\
                                    'tertiary_bus':None, 'tert_name':'None',\
                                    'ckt':ckt.strip(), 'type':btype.strip(), 'status':status=='True',
                                    'R12':float(r), 'X12':float(x),
                                    'R31':None, 'X31':None,
                                    'R23':None, 'X23':None,})

                for key, brns in star_buses.items():

                    dct = {bus:{'name':name, 'ckt':ckt, 'type':typ, 'status':status,
                                'r':float(r), 'x':float(x), 'b':float(b) } for bus, name, ckt, typ, status, r, x, b in brns}

##                    print('TEST2!!!')
##                    print('\n')
##                    print(buses)
                    sorted_buses = sorted([brns[i][0] for i in range(len(brns))])
                    
                    rp = (dct[sorted_buses[0]]['r']*dct[sorted_buses[1]]['r']) + \
                         (dct[sorted_buses[1]]['r']*dct[sorted_buses[2]]['r']) + \
                         (dct[sorted_buses[2]]['r']*dct[sorted_buses[0]]['r'])

                    xp = (dct[sorted_buses[0]]['x']*dct[sorted_buses[1]]['x']) + \
                         (dct[sorted_buses[1]]['x']*dct[sorted_buses[2]]['x']) + \
                         (dct[sorted_buses[2]]['x']*dct[sorted_buses[0]]['x'])

                    r23 = rp/dct[sorted_buses[0]]['r']
                    r31 = rp/dct[sorted_buses[1]]['r']
                    r12 = rp/dct[sorted_buses[2]]['r']

                    x23 = xp/dct[sorted_buses[0]]['x']
                    x31 = xp/dct[sorted_buses[1]]['x']
                    x12 = xp/dct[sorted_buses[2]]['x']

                    R12 = r12/((max([buses[sorted_buses[0]]['kv'], buses[sorted_buses[1]]['kv']])**2.)/100.)
                    R23 = r23/((max([buses[sorted_buses[1]]['kv'], buses[sorted_buses[2]]['kv']])**2.)/100.)
                    R31 = r31/((max([buses[sorted_buses[2]]['kv'], buses[sorted_buses[0]]['kv']])**2.)/100.)

                    X12 = x12/((max([buses[sorted_buses[0]]['kv'], buses[sorted_buses[1]]['kv']])**2.)/100.)
                    X23 = x23/((max([buses[sorted_buses[1]]['kv'], buses[sorted_buses[2]]['kv']])**2.)/100.)
                    X31 = x31/((max([buses[sorted_buses[2]]['kv'], buses[sorted_buses[0]]['kv']])**2.)/100.)

                    sorted_buses = sorted([brns[i][0] for i in range(len(brns))])
                    
                    tmp.append({'from_bus':int(sorted_buses[0]), 'from_name':dct[sorted_buses[0]]['name'],\
                                'to_bus':int(sorted_buses[1]), 'to_name':dct[sorted_buses[1]]['name'],\
                                'tertiary_bus':int(sorted_buses[2]), 'tert_name':dct[sorted_buses[2]]['name'],\
                                'ckt':dct[sorted_buses[0]]['ckt'],
                                'type':dct[sorted_buses[0]]['type'],
                                'status':dct[sorted_buses[0]]['status']=='True',
                                'R12':R12, 'X12':X12, 'R23':R23, 'X23':X23, 'R31':R31, 'X31':X31,
                                })
                    
            return tmp
        else:
            err = getattr(errors, err_dict[int(n)])
            raise err

    def get_breakers(self):
        """
        Retrieve circuit breakers in PCG

        :returns: [{'from_pcg_index': from PCG index *(int)*, 'from_sub': from substation # *(int)*, 'from_bus': from bus # *(int)*, 'from_node': from node id *(str)*,
                  'to_pcg_index': to PCG index *(int)*, 'to_sub': to substation # *(int)*, 'to_bus': to bus # *(int)*, 'to_node': to node id *(str)*,
                  'id': breaker id *(str)*, 'name': breaker name *(str)*, 'sub_name': substation name *(str)*},...]
        """

        if self.is_truncated == True:
            return []
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}
        try:
            # Get data from dll
            res = self.parser.get_breakers(self.indx)
            (err, brks) = (res[0]=="True", res[1:])

            if err == False:
                if brks == []:
                    return []
                else:
                    tmp = []
                    for line in brks:
                        fr_pcg_indx, fr_sub, fr_bus, fr_node, to_pcg_indx, to_sub, to_bus, to_node, brk_id, brk_name, sub_name = line.split(',')

                        if fr_pcg_indx != "None":
                            fr_pcg_indx = int(fr_pcg_indx)
                        else:
                            fr_pcg_indx = None
                            
                        if to_pcg_indx != "None":
                            to_pcg_indx = int(to_pcg_indx)
                        else:
                            to_pcg_indx = None
                        
                        tmp.append({'from_pcg_index':fr_pcg_indx, 'from_sub':int(fr_sub), 'from_bus':int(fr_bus), 'from_node':fr_node.strip(),
                                    'to_pcg_index':to_pcg_indx, 'to_sub':int(to_sub), 'to_bus':int(to_bus), 'to_node':to_node.strip(),
                                    'id':brk_id.strip(), 'name':brk_name.strip(), 'sub_name':sub_name.strip()})
                    return tmp
            else:
                err = getattr(errors, err_dict[int(brks)])
                raise err
        except Exception as e:
            print('error retrieving breakers from PCG #{}'.format(self.indx))
            print(e)
            return []
        
    def get_generators(self):
        """
        Retrieve generators in PCG

        :returns: [{'bus': bus # *(int)*, 'name': bus name *(str)*, 'id': generator id *(str)*, 'status': generator status *(bool)*},...]
        """

        if self.is_truncated == True:
            return []
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}

        # Get data from dll
        res = self.parser.get_generators(self.indx)
        (err, gens) = (res[0]=="True", res[1:])

        if err == False:
            if gens == []:
                return []
            else:
                tmp = []
                for line in gens:
                    bus, m_id, name, status = line.split(',')
                    tmp.append({'bus':int(bus), 'id':m_id.strip(), 'name':name.strip(), 'status':status=='True'})
                return tmp
        else:
            err = getattr(errors, err_dict[int(gens)])
            raise err

    def get_in_study_spec(self):
        """
        Retrieve study area membership flag for PCG

        :returns: flag *(bool)*
        """
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}
        
        # Get data from dll
        res = self.parser.get_in_study_spec(self.indx)
        (err, flag) = (res[0]=="True", res[1])

        if err == False:
            return flag=='True'
        else:
            err = getattr(errors, err_dict[int(flag)])
            raise err
        
    def get_nodes(self):
        """
        Retrieve nodes in PCG

        :returns: [{'substation': substation # *(int)*, 'substation_name', substation name *(str)*, 'bus': bus # *(int)*, 'id': node ID *(str)*},...]
        """

        if self.is_truncated == True:
            return []
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}

        # Get data from dll
        res = self.parser.get_nodes(self.indx)
        (err, nodes) = (res[0]=="True", res[1:])

        if err == False:
            if nodes == []:
                return []
            else:
                tmp = []
                for line in nodes:
                    sub, sub_name, bus, n_id = line.split(',')
                    tmp.append({'substation':int(sub), 'substation_name': sub_name.strip(), 'bus':int(bus), 'id':n_id.strip()})
                return tmp
        else:
            err = getattr(errors, err_dict[int(nodes)])
            raise err

    def get_pcg_area_numbers(self):
        """
        Retrieve the area numbers for buses associated with the pcg

        :returns: [area # *(int)*,...]
        """

        if self.is_truncated == True:
            return []
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}

        # Get data from dll
        res = self.parser.get_bus_area_numbers(self.indx)
        (err, areas) = (res[0]=="True", res[1:])

        if err == False:
            return sorted([int(n) for n in areas])
        else:
            err = getattr(errors, err_dict[int(areas)])
            raise err
        
    def get_pcg_buses(self):
        """
        Retrieve buses associated with the pcg

        :returns: {bus # *(int)*: {'bus_name': bus name *(str)*, 'substation_name': substation name *(str)*,
                                   'kv': bus base voltage *(float)*, 'star_bus': is star bus *(bool)*},...}
        """

        if self.is_truncated == True:
            return {}
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}

        # Get data from dll
        res = self.parser.get_buses(self.indx)
        (err, buses) = (res[0]=="True", res[1:])

        if err == False:
            ret = {}
            for line in buses:
                bus_n, bus_name, sub_name, kv, star = line.split(',')
                ret[int(bus_n)] = {'bus_name':bus_name.strip(), 'substation_name':sub_name.strip(),
                                   'kv':float(kv), 'star_bus':star.strip().lower()=='true'}
            return ret
        else:
            err = getattr(errors, err_dict[int(buses)])
            raise err
        
    def get_pcg_owner_numbers(self):
        """
        Retrieve the owner numbers for buses associated with the pcg

        :returns: [owner # *(int)*,...]
        """

        if self.is_truncated == True:
            return []
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}

        # Get data from dll
        res = self.parser.get_bus_owner_numbers(self.indx)
        (err, owners) = (res[0]=="True", res[1:])

        if err == False:
            return sorted([int(n) for n in owners])
        else:
            err = getattr(errors, err_dict[int(owners)])
            raise err

        
    def get_pcg_zone_numbers(self):
        """
        Retrieve the zone numbers for buses associated with the pcg
        :returns: [zone # *(int)*,...]
        """

        if self.is_truncated == True:
            return []
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}

        # Get data from dll
        res = self.parser.get_bus_zone_numbers(self.indx)
        (err, zones) = (res[0]=="True", res[1:])

        if err == False:
            return sorted([int(n) for n in zones])
        else:
            err = getattr(errors, err_dict[int(zones)])
            raise err

    def get_shunts(self):
        """
        Retrieve shunts associated with the PCG

        :returns: [{'bus': bus # *(int)*, 'name': bus name *(str)*, 'id': shunt ID *(str)*, 'type': shunt type *(str)*, 'status': shunt status *(bool)*},...]
        """
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}

        if self.is_truncated == True:
            return []
        
        # Get data from dll
        res = self.parser.get_shunts(self.indx)
        (err, shunts) = (res[0]=="True", res[1:])

        if err == False:
            if shunts == []:
                return []
            else:
                tmp = []
                for line in shunts:
                    bus, name, s_id, s_type, status = line.split(',')
                    tmp.append({'bus':int(bus), 'name':name.strip(), 'id':s_id.strip(), 'type':s_type.strip(), 'status':status=='True'})
                return tmp
        else:
            err = getattr(errors, err_dict[int(shunts)])
            raise err
        
    def get_sub_indx(self):
        """
        Retrieve indexes of the PCG's connected substations

        :returns: sub index ([int])
        """
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}

        # Get data from dll
        res = self.parser.get_sub_indexes(self.indx)
        (err, indxs) = (res[0]=="True", res[1:])

        if err == False:
            return sorted([int(n) for n in indxs])
        else:
            err = getattr(errors, err_dict[int(indxs)])
            raise err

    def get_terminal_branches(self):
        """
        Retrieve terminal branches associated with PCG

        :returns: [{'from_bus': from bus # *(int)*, 'to_bus': to bus # *(int)*,
                    'tertiary_bus': tertiary bus # *(int)*, 'ckt': branch circuit ID *(str)*,
                    'type': branch type *(str)*, 'status': branch status *(bool)*},...]
        """
        
        if self.is_truncated == True:
            return []
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}

        # Get data from dll
        res = self.parser.get_terminal_branches(self.indx)
        (err, brns) = (res[0]=="True", res[1:])

        if err == False:
            tmp = []
            for brn in brns:
                (fr, to, tert, ckt, btype, status) = brn.split(',')
                try:
                    tert=int(tert)
                except ValueError:
                    tert = None
                tmp.append({'from_bus':int(fr), 'to_bus':int(to), 'tertiary_bus':tert, 'ckt':ckt.strip(), 'type':btype.strip(), 'status':status=='True'})
            return tmp
        else:
            err = getattr(errors, err_dict[int(brns)])
            raise err

    def get_terminal_buses(self):
        """
        Retrieve terminal bus numbers associated with PCG

        :returns: [bus # *(int)*,...]
        """
        
        if self.is_truncated == True:
            return []
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}

        # Get data from dll
        res = self.parser.get_terminal_buses(self.indx)
        (err, buses) = (res[0]=="True", res[1:])

        if err == False:
            return [int(bus) for bus in buses]
        else:
            err = getattr(errors, err_dict[int(buses)])
            raise err
        
    def is_swing_in_pcg(self):
        """
        Determine if PCG contains a swing bus

        :returns: flag *(bool)*
        """
        
        if self.is_truncated == True:
            return []
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}

        # Get data from dll
        res = self.parser.is_swing_in_pcg(self.indx)
        (err, tf) = (res[0]=="True", res[1])

        if err == False:
            return tf == "True"
        else:
            err = getattr(errors, err_dict[int(n)])
            raise err
        
