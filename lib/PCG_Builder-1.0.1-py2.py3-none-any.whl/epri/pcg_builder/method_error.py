#********************************************************#
# This file is part of ACGT.                             #
#                                                        #
# Copyright (c) 2020, Electric Power Research Institute. #
#                                                        #
# GRIDOPT is released under the BSD 3-clause license.    #
#********************************************************#

class PCGmethodError(Exception):
    """
    Generic exception
    """
    pass

class PCGmethodError_InvalidFileName(PCGmethodError):
    """
    Not able to find the supplied filename
    """
    def __init__(self, filename=None):
        PCGmethodError.__init__(self, 'File not found: {}'.format(filename))

class PCGmethodError_MissingPFModel(PCGmethodError):
    """
    No powerflow model present in file parser object
    """
    def __init__(self):
        PCGmethodError.__init__(self, 'No powerflow model loaded')

class PCGmethodError_MissingParser(PCGmethodError):
    """
    No powerflow file parser present
    """
    def __init__(self):
        PCGmethodError.__init__(self, 'File parser has not been initialized') 

class PCGmethodError_EmptyPCGList(PCGmethodError):
    """
    No PCGs found in powerflow model
    """
    def __init__(self):
        PCGmethodError.__init__(self, 'PCG list has not been constructed')
 
