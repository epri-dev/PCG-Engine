#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function

def main():
    from ..pcg_builder import parser

    file_parser = parser.Parser()
    print(file_parser.parse_file(r'C:\Users\pkdo002\source\repos\ACGT\Tutorial\PSSE\ne_39.raw'))
    print(file_parser.build_pcgs(debug=True))
    print(file_parser.get_num_pcgs())
##    print(file_parser.get_system_base())
##    print(file_parser.get_case_comments())
##    print(file_parser.get_num_buses())
##    print(file_parser.get_bus_name(1))
    print('\n\n')
    
    file_parser = parser.Parser()
    print(file_parser.parse_file(r'C:\Users\pkdo002\source\repos\ACGT\PSLFTutorial\NE_39.epc'))
    print(file_parser.build_pcgs(debug=True))
    print(file_parser.get_num_pcgs())
##    print(file_parser.get_system_base())
##    print(file_parser.get_case_comments())
##    print(file_parser.get_num_buses())
##    print(file_parser.get_bus_name(1))
    print('\n\n')
##    print(file_parser.parse(r'ObviouslyNotARealFile.raw'))
