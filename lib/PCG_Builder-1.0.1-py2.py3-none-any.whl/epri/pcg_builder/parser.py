#!/usr/bin/env python
# -*- coding: utf-8 -*-
#********************************************************#
# This file is part of ACGT.                             #
#                                                        #
# Copyright (c) 2020, Electric Power Research Institute. #
#                                                        #
# GRIDOPT is released under the BSD 3-clause license.    #
#********************************************************#
from __future__ import print_function
import clr, os, sys

try:
    import method_error as errors
except ModuleNotFoundError:
    import epri.pcg_builder.method_error as errors
    
assembly_path = r"lib"
sys.path.append(assembly_path)

clr.AddReference("QuickGraph")
clr.AddReference("PCG")

from QuickGraph import AdjacencyGraph
from PCG import FileParser

class Parser:
    """
    Powerflow file parser class
    """
    
    def __init__(self):
        
        self.file_parser = FileParser()

    def build_pcgs(self, debug=False):
        """
        Build protection control groups (PCG)

        :param debug: run parser in debug mode for extra output? *(bool)*
        :returns: file parser console output *(str)* 
        """

        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}
        
        res = self.file_parser.build_pcgs(debug)
        (err, out) = (res[0]=="True", res[1:])

        if err == False:
            return out
        else:
            err = getattr(errors, err_dict[int(out[0])])
            print(out[1])
            raise err
        
    def parse_file(self, fname=None):
        """
        Parse file

        :param fname: powerflow file name *(str)*
        :return: file parser console output *(str)* 
        """

        if os.path.isfile(fname):
            return self.file_parser.parse_file(fname)
        else:
            raise errors.PCGmethodError_InvalidFileName(fname)

    def get_bus_name(self, bus):
        """
        Retrieve bus name from bus number

        :param bus: bus number *(int)*
        :returns: bus name *(str)*
        """
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}
        
        res = self.file_parser.get_bus_name(bus)
        (err, name) = (res[0]=="True", res[1])

        if err == False:
            return name
        else:
            err = getattr(errors, err_dict[int(name)])
            raise err
        
    def get_case_comments(self):
        """
        Retrieve powerflow model comments

        :returns: powerflow case comments *(str[])*
        """
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}
        
        res = self.file_parser.get_case_comments()
        (err, comments) = (res[0]=="True", res[1:])

        if err == False:
            return comments
        else:
            err = getattr(errors, err_dict[int(comments)])
            raise err     

    def get_num_buses(self):
        """
        Retrieve number of buses in powerflow model

        :returns: # buses *(int)*
        """
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}
        
        res = self.file_parser.get_num_buses()
        (err, n) = (res[0]=="True", res[1])

        if err == False:
            return int(n)
        else:
            err = getattr(errors, err_dict[int(n)])
            raise err

    def get_num_pcgs(self):
        """
        Retrieve number of pcgs in powerflow model

        :returns: # pcgs *(int)*
        """
        
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",
                    3: "PCGmethodError_EmptyPCGList",}
        
        res = self.file_parser.get_num_pcgs()
        (err, n) = (res[0]=="True", res[1])

        if err == False:
            return int(n)
        else:
            err = getattr(errors, err_dict[int(n)])
            raise err
        
    def get_system_base(self):
        """
        Retrieve powerflow model MVA base

        :returns: system MVA base *(float)*
        """
        err_dict = {1: "PCGmethodError_MissingPFModel",
                    2: "PCGmethodError_MissingParser",}
        
        res = self.file_parser.get_system_base()
        (err, mva) = (res[0]=="True", res[1])

        if err == False:
            return float(mva)
        else:
            err = getattr(errors, err_dict[int(mva)])
            raise err 

    def set_study_areas(self, areas):
        """
        Select which powerflow model areas to include in the study area

        :param areas: area # *(int[])*
        """
        
        self.file_parser.clear_study_areas()
        areas = [int(x) for x in areas]
        for x in areas:
            self.file_parser.add_study_area(x)
        
    def set_study_buses(self, buses):
        """
        Select which powerflow model buses to include in the study area

        :param buses: bus # *(int[])*
        """
        
        self.file_parser.clear_study_buses()
        buses = [int(x) for x in buses]
        for x in buses:
            self.file_parser.add_study_bus(x)
            
    def set_study_kv(self, kv):
        """
        Select which powerflow model voltage classes to include in the study area

        :param kv: voltage range *(float, float)*
        """
        
        kv = [float(x) for x in kv]
        self.file_parser.set_study_kv_range(min(kv), max(kv))
            
    def set_study_owners(self, owners):
        """
        Select which powerflow model owners to include in the study area

        :param owners: owner # *(int[])*
        """
        
        self.file_parser.clear_study_owners()
        owners = [int(x) for x in owners]
        for x in owners:
            self.file_parser.add_study_owner(x)

    def set_study_substations(self, subs):
        """
        Select which powerflow model substations to include in the study area

        :param subs: substation # *(int[])*
        """
        
        self.file_parser.clear_study_substations()
        subs = [int(x) for x in subs]
        for x in subs:
            self.file_parser.add_study_substation(x)
            
    def set_study_zones(self, zones):
        """
        Select which powerflow model zones to include in the study area

        :param zones: zone # *(int[])*
        """

        self.file_parser.clear_study_zones()
        zones = [int(x) for x in zones]
        for x in zones:
            self.file_parser.add_study_zone(x)
