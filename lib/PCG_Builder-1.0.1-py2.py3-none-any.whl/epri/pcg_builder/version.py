#********************************************************#
# This file is part of PCG Builder.                      #
#                                                        #
# Copyright (c) 2020, Electric Power Research Institute. #
#                                                        #
# GRIDOPT is released under the BSD 3-clause license.    #
#********************************************************#
__version__ = '1.0.1'
